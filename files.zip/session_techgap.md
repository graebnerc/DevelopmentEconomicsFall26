# Session 7: Technology, Innovation, and Trade-Led Development

## Session Overview

This session introduces the Neo-Schumpeterian and evolutionary economics perspective
on development, with a particular focus on the **technology gap literature** as a
bridge between the institutional frameworks discussed in Sessions 5–6 and the
Marxist/dependency critique from Sessions 7–8. The central argument is that
persistent international inequality is not merely a product of factor endowments
or institutional quality, but of *structural differences in technological
capabilities* that are self-reinforcing and path-dependent.

## Learning Objectives

Upon completing this session, students will be able to:

- Explain the concept of technology gaps and their role in perpetuating
  international inequality
- Describe the key mechanisms of the National Systems of Innovation (NSI) framework
- Connect Neo-Schumpeterian arguments about technological divergence to the
  dependency theory critique of the previous sessions
- Critically evaluate the policy implications of the technology gap approach,
  including its assumptions and blind spots
- Contrast East Asian and Latin American development trajectories through the
  lens of innovation systems

## Connecting Thread: From Marx to Schumpeter

The dependency theory sessions established that underdevelopment is *structurally
reproduced* through unequal exchange and core–periphery dynamics. A key weakness
of classical dependency theory, however, is that it often describes *what*
maintains the periphery's subordinate position without fully explaining *how* this
subordination is reproduced at the micro-level of firms and industries.

The technology gap literature fills this gap. Like dependency theorists, authors
such as Fagerberg, Verspagen, and Dosi reject the neoclassical assumption that
technology is a freely available public good that diffuses automatically across
borders. Instead, they argue:

- Technological capabilities are **tacit, cumulative, and locally embedded** —
  they cannot simply be imported or copied
- Innovation is **path-dependent**: countries with weak technological bases find
  it harder, not easier, to catch up over time
- International trade and investment, absent deliberate policy, tend to
  **reinforce** rather than reduce technological gaps

This resonates directly with the dependency argument: both traditions see the
international economy as generating divergence rather than convergence. The
key difference is *mechanism* — where dependency theory foregrounds surplus
extraction and unequal exchange, the technology gap literature foregrounds
absorptive capacity, learning-by-doing, and systemic innovation failure.

## Key Concepts

**Technology Gap**
: The difference in technological capabilities between countries, measured not
  only in R&D expenditure but in the broader capacity to absorb, adapt, and
  generate innovations. Gaps are self-reinforcing: falling behind reduces the
  capacity to catch up.

**National Systems of Innovation (NSI)**
: The network of institutions — firms, universities, public agencies, financial
  systems, legal frameworks — that together shape a country's capacity to
  innovate (Freeman 1987; Lundvall 1992; Nelson 1993). The NSI framework
  argues that innovation is a *systemic* process: no single firm or policy
  instrument can substitute for a functioning innovation ecosystem.

**Catching Up, Forging Ahead, Falling Behind**
: Abramovitz's (1986) framework distinguishes countries by their position
  relative to the technological frontier. Catching up requires not just
  investment but *social capability* — the institutional and human capital
  preconditions for absorbing and deploying new technologies productively.

**Technological Paradigms and Trajectories**
: Dosi (1982) argues that innovation follows trajectories defined by dominant
  paradigms (e.g., fossil-fuel-based industrialisation, digital computing).
  Late-developing countries face the challenge of entering existing trajectories
  while also positioning for future ones — a double burden.

## Session Structure (90 minutes)

| Time | Content |
|------|---------|
| 0–10 min | Recap: what dependency theory explains — and what it leaves open |
| 10–30 min | Technology gaps: concept, evidence, and self-reinforcing dynamics |
| 30–50 min | National Systems of Innovation: institutions as innovation infrastructure |
| 50–65 min | Case studies: East Asia vs. Latin America |
| 65–80 min | Critical discussion: does NSI escape Eurocentrism? |
| 80–90 min | Outlook: why degrowth challenges the catch-up model |

## Case Studies

### East Asia: Deliberate Capability Building
South Korea and Taiwan pursued explicit industrial and technology policies —
directed credit, public R&D, selective protection of infant industries, and
investment in education — that gradually built domestic technological capabilities.
The NSI literature points to strong state–industry coordination and long-term
investment horizons as key enabling factors. Crucially, these states *intervened
against* market signals in the short run to build capabilities for the long run.

### Latin America: Structural Heterogeneity and Truncated Industrialisation
Despite similar starting points and in some cases earlier industrialisation,
most Latin American economies did not achieve sustained technological catch-up.
Structuralist and dependency theorists point to the enclave nature of FDI,
commodity dependence, and external debt constraints. The NSI lens adds:
fragmented innovation systems, weak university–industry linkages, and stop-go
macroeconomic instability that discouraged long-term investment in capabilities.

The contrast matters: both regions faced dependency-style constraints, but
institutional and political differences in how they managed the *technology
dimension* of development help explain divergent outcomes.

## Pros and Cons of the Technology Gap / NSI Approach

### Strengths

- **Micro-founded mechanism**: Explains *how* inequality is reproduced at the
  level of firms and industries, complementing macro-structural accounts
- **Policy actionable**: Points clearly to industrial policy, public R&D, and
  education as levers — more specific than dependency theory's prescription to
  "de-link"
- **Empirically grounded**: Substantial econometric literature linking innovation
  indicators to growth and convergence (Fagerberg & Verspagen 2002; Castellacci 2008)
- **Avoids technological determinism**: The NSI framework insists that technology
  is socially shaped — institutions matter, not just R&D budgets
- **Bridges paradigms**: Compatible with both institutionalist and (partially)
  with dependency-influenced structuralism

### Weaknesses and Critiques

- **Latent Eurocentrism**: The "catching up" framing implicitly takes the
  industrial North as the universal model of development — a form of modernisation
  theory in evolutionary clothing
- **State capacity assumption**: Industrial and innovation policies require
  capable, insulated bureaucracies. Where these do not exist, prescriptions may
  be unimplementable — and the literature says relatively little about how to
  build such capacity
- **Ecological blind spot**: The catch-up model assumes that late industrialisers
  should replicate Northern production patterns — precisely what the next session's
  degrowth critique challenges. Can the planet sustain universal industrialisation
  on the Northern model?
- **Power relations undertheorised**: Compared to dependency theory, the NSI
  framework pays little attention to how global power structures (IP regimes,
  WTO rules, conditionality) actively *prevent* late developers from pursuing
  the same policies that early developers used
- **Selection on success**: The East Asian "miracle" countries are intensively
  studied; failed catching-up attempts receive less attention, potentially biasing
  policy lessons

## Bridge to the Next Session

The technology gap approach is, at its core, optimistic: with the right
institutions and policies, late developers can catch up to the technological
frontier. The following session on sustainable development and degrowth poses a
fundamental challenge to this optimism: *what if the frontier itself is the
problem?* If Northern consumption and production patterns are ecologically
unsustainable, then replicating them globally — even with better innovation
systems — is not a viable development strategy. This tension between catch-up
optimism and ecological realism is one of the deepest unresolved problems in
contemporary development economics.

## Key References

- Abramovitz, M. (1986). Catching up, forging ahead, and falling behind.
  *Journal of Economic History*, 46(2), 385–406.
- Dosi, G. (1982). Technological paradigms and technological trajectories.
  *Research Policy*, 11(3), 147–162.
- Fagerberg, J., & Verspagen, B. (2002). Technology-gaps, innovation-diffusion
  and transformation. *Research Policy*, 31(8–9), 1291–1304.
- Freeman, C. (1987). *Technology Policy and Economic Performance: Lessons from
  Japan*. Pinter.
- Lundvall, B.-Å. (Ed.). (1992). *National Systems of Innovation*. Pinter.
- Nelson, R. R. (Ed.). (1993). *National Innovation Systems: A Comparative
  Analysis*. Oxford University Press.
- Prebisch, R. (1950). *The Economic Development of Latin America and its
  Principal Problems*. ECLA/UN. *(Link to dependency theory)*
- Verspagen, B. (1991). A new empirical approach to catching up or falling
  behind. *Structural Change and Economic Dynamics*, 2(2), 359–380.
