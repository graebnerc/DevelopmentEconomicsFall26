## Schedule and Logistics

::: {.callout-important}
**Note:** This schedule is subject to change as the course progresses.
Announcements will be made via Moodle. The latest version of the syllabus
will be made available here.
:::

| #  | Date        | Topic                                                        | Format    |
|----|-------------|--------------------------------------------------------------|-----------|
| 1  | 18.09.      | Introduction and the meaning of 'development'                | In-person |
| 2  | 25.09.      | Measuring development                                        | In-person |
| 3  | 02.10.      | Human Development and the Capabilities Approach              | In-person |
|    | 09.10.      | Classical and Neoclassical Growth Models                     | Video     |
|    | 16.10.      | *No lecture*                                                 |           |
| 4  | 23.10.      | Institutional Economics and Development I                    | In-person |
| 5  | 30.10.      | Institutional Economics and Development II                   | In-person |
| 6  | 06.11.      | Marxist Theories of Development                              | In-person |
| 7  | 13.11.      | Dependency Theory                                            | In-person |
| 8  | 20.11.      | Technology, Innovation, and Trade-Led Development            | In-person |
| 9  | 27.11.      | Sustainable Development, Environmental Limits, and Degrowth  | In-person |
| 10 | 04.12.      | *Buffer / Exam Preparation*                                  | In-person |
| 11 | 11.12.      | Summary and Open Questions                                   | In-person |

::: {.callout-warning}
### Exam Dates
- **First Exam:** tbd
- **Second Exam:** tbd
:::
